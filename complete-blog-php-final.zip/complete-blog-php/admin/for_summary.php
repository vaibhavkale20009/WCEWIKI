<?php  include('../config.php'); ?>
<?php  include(ROOT_PATH . '/admin/includes/admin_functions.php'); ?>
<?php  include(ROOT_PATH . '/admin/includes/post_functions.php'); ?>
<?php include(ROOT_PATH . '/admin/includes/head_section.php'); ?>
<!-- Get all topics -->
<?php $topics = getAllTopics();	?>
	<title>Admin | Create Post</title>
</head>
<body>
	<!-- admin navbar -->
	<?php include(ROOT_PATH . '/admin/includes/navbar.php') ?>

	<div class="container content">
		<!-- Left side menu -->
        <?php include(ROOT_PATH . '/admin/includes/menu.php') ?>
        <?php if (isset($_GET['summarize-post'])) {
	$post_id = $_GET['summarize-post'];
	summarizePost($post_id);
    }
        ?>
        <?php
        function summarizePost($role_id)
	    {
		global $conn, $title, $post_slug, $body, $published, $isEditingPost, $post_id;
		$sql = "SELECT * FROM posts WHERE id=$role_id LIMIT 1";
		$result = mysqli_query($conn, $sql);
		$post = mysqli_fetch_assoc($result);
		// set form values on the form to be updated
		$title = $post['title'];
		$body = $post['body'];
		$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
                fwrite($myfile, $body);
          
			$output = shell_exec('python Text-summarization.py');
		
		$query= "INSERT INTO posts('summarize') VALUES($output) WHERE id=$role_id LIMIT 1"; 
		
			echo $output; 	
		
		
	    }
        ?>
		
	</div>
</body>
</html>
