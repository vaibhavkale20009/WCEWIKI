       <div class="navbar">
			<div class="logo_div">
				<a href="index.php"><h1>WCE Wiki</h1></a>
			</div>
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="contact-us.html">Contact</a></li>
			  <li><a href="about-us.html">About</a></li>
			</ul>
		</div>