<div class="footer">
			<p>WCE Wiki &copy; <?php echo date('Y'); ?></p>
		</div>