<?php
	include("summarizer.class.php");

ob_start();
?>
This is part 3 of a 4-part series on How To Build a Blog with PHP and MySQL. You can view the previous two parts here: part 1, part 2.

In the last two parts of this tutorial, we finished creating the public area. We even set up our database, inserted some data into the database tables and were able to query this and display on the page. But we don't always want to create users, posts, topics using a database client like PHPMyAdmin, do we? We want an interface on the website and a logged in user with admin privileges to do that. 

When a user with admin privileges logs in, they are automatically redirected to the admin dashboard. But we haven't created an admin user in our system yet. We will do that soon.
<?php
$content = ob_get_contents();
ob_end_clean();

    $st = new Summarizer();
    $summary = $st->get_summary($content);
	echo $summary;
	var_dump($st->how_we_did());


?>